The Fink Package Manager Team
=============================

Original author (retired)
-------------------------
Christoph Pfisterer <cp@chrisp.de>

Current maintainers
------------------
Alexander Hansen  <alexkhansen@users.sourceforge.net>

Max Horn <max@quendi.de>

Daniel Macks <dmacks@netspace.org>

Dave Morrison <drm@finkproject.org>

Benjamin Reed <rangerrick@users.sourceforge.net>

Dave Vasilevsky  <vasi@users.sourceforge.net>

Contributors
------------
Rob Braun <bbraun@users.sourceforge.net>

Martin Costabel <costabel@wanadoo.fr>

Sylvain Cuaz <zauc@users.sourceforge.net>

Brendan Cully <brendan@finkproject.org>

Finlay Dobbie <finlayd@users.sourceforge.net>

Justin F. Hallett <thesin@southofheaven.net>

Mohammad A. Haque  <batmanppc@users.sourceforge.net>

Ben Hines <benh57@users.sourceforge.net>

Jack Howarth <howarth@bromo.med.uc.edu>

Daniel Johnson <daniel@daniel-johnson.org>

Carsten Klapp <carstenklapp@users.sourceforge.net>

Sebastien Maret <bmaret@users.sourceforge.net>

Remi Mommsen <remigius.mommsen@cern.ch>

Matthias Neeracher <neeracher@mac.com>

Hanspeter Niederstrasser <nieder@users.sourceforge.net>

Peter O'Gorman <ogorman@users.sourceforge.net>

Daniel Parks <daniel@maywallacedesign.com>

Matthew Sachs <msachs@apple.com>

Christian Schaffner <chris01@users.sourceforge.net>

Michael G Schwern <schwern@pobox.com>

Chris Zubrzycki <beren12@users.sourceforge.net>


